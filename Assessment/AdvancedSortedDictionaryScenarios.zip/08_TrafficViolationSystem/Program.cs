
using System;
using Services;
using Domain;

class Program
{
    static void Main()
    {
        Console.WriteLine("08_TrafficViolationSystem - Boilerplate");
        ManagementService service = new ManagementService();

        // TODO: Create entity
        // TODO: Add entity
        // TODO: Trigger custom exceptions
        // TODO: Display sorted results

        Console.ReadLine();
    }
}
